﻿//using System;

//class Recommender
//{
//    // Create a user-item rating matrix
//    private static double[,] ratings = new double[,] {
//        { 5, 3, 0, 1 },
//        { 4, 0, 0, 1 },
//        { 1, 1, 0, 5 },
//        { 1, 0, 0, 4 },
//        { 0, 1, 5, 4 },
//    };

//    public static void Main()
//    {
//        // Perform matrix factorization
//        var userFactors = MatrixFactorization(ratings);

//        // Use the factorized matrices to generate predictions for unrated items
//        double predictedRating = PredictRating(userFactors, 0, 3);
//        Console.WriteLine("Predicted rating for user 0 and item 3: " + predictedRating);
//    }

//    // Method to perform matrix factorization
//    private static double[,] MatrixFactorization(double[,] ratings)
//    {
//        // Initialize the user and item factors with random values
//        double[,] userFactors = RandomMatrix(ratings.GetLength(0), 2);
//        double[,] itemFactors = RandomMatrix(ratings.GetLength(1), 2);

//        // Perform matrix factorization with gradient descent
//        // Repeat this process for a certain number of iterations
//        // or until the error is below a certain threshold
//        for (int iteration = 0; iteration < 100; iteration++)
//        {
//            // Update the user factors
//            for (int i = 0; i < ratings.GetLength(0); i++)
//            {
//                for (int j = 0; j < ratings.GetLength(1); j++)
//                {
//                    if (ratings[i, j] > 0)
//                    {
//                        double error = ratings[i, j] - DotProduct(userFactors, i, itemFactors, j);
//                        for (int k = 0; k < 2; k++)
//                        {
//                            userFactors[i, k] += 0.01 * error * itemFactors[j, k];
//                            itemFactors[j, k] += 0.01 * error * userFactors[i, k];
//                        }
//                    }
//                }
//            }
//        }

//        return userFactors;
//    }

//    // Method to generate a random matrix
//    private static double[,] RandomMatrix(int rows, int cols)
//    {
//        double[,] matrix = new double[rows, cols];
//        Random rand = new Random();
//        for (int i = 0; i < rows; i++)
//        {
//            for (int j = 0; j < cols; j++)
//            {
//                matrix[i, j] = rand.NextDouble();
//            }
//        }
//        return matrix;
//    }

//    // Method to calculate dot product
//    private static double DotProduct(double[,] matrixA, int rowA, double[,] matrixB, int colB)
//    {
//        double result = 0;
//        for (int i = 0; i < matrixA.GetLength(1); i++)
//        {
//            result += matrixA[rowA, i] * matrixB[i, colB];
//        }
//        return result;
//    }

//    // Method to predict a rating for an unrated item
//    private static double PredictRating(double[,] userFactors, int userId, int itemId)
//    {
//        double predictedRating = 0;
//        for (int i = 0; i < userFactors.GetLength(1); i++)
//        {
//            predictedRating += userFactors[userId, i] * itemFactors[itemId, i];
//        }
//        return predictedRating;
//    }
//}

using System;
using System.Linq;

class SimilarityMatrix
{
    static void Main()
    {
        // Example data
        double[,] data = { { 3, 4, 3 }, { 2, 3, 4 }, { 3, 4, 5 }, { 1, 2, 3 } };

        // Calculate the similarity matrix
        double[,] similarityMatrix = CalculateSimilarityMatrix(data);

        // Print the similarity matrix
        for (int i = 0; i < similarityMatrix.GetLength(0); i++)
        {
            for (int j = 0; j < similarityMatrix.GetLength(1); j++)
            {
                Console.Write(similarityMatrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }

    static double[,] CalculateSimilarityMatrix(double[,] data)
    {
        int rows = data.GetLength(0);
        int cols = data.GetLength(1);

        double[] rowMagnitudes = new double[rows];
        for (int i = 0; i < rows; i++)
        {
            double sum = 0;
            for (int j = 0; j < cols; j++)
            {
                sum += data[i, j] * data[i, j];
            }
            rowMagnitudes[i] = Math.Sqrt(sum);
        }

        double[,] similarityMatrix = new double[rows, rows];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                double dotProduct = 0;
                for (int k = 0; k < cols; k++)
                {
                    dotProduct += data[i, k] * data[j, k];
                }
                similarityMatrix[i, j] = dotProduct / (rowMagnitudes[i] * rowMagnitudes[j]);
            }
        }
        return similarityMatrix;
    }
}